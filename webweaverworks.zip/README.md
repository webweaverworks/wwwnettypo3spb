Base Sitepackage for the project Webweaverworks
==============================================================

Add some explanation here.
